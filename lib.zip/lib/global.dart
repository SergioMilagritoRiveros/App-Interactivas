library my_prj.globals;

bool isDarkMode = false;